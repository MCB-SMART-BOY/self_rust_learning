use std::collections::HashMap;
use std::io;
use std::io::Write;

fn main() {
  println!("———— 员工管理系统 ————");
  println!("命令格式：");
  println!("Add <姓名> to <部门>");
  println!("List all");
  println!("List <部门>");
  println!("Quit");
  println!("————————————————————");

  let mut company_departments: HashMap<String, Vec<String>> = HashMap::new();//先设定公司部门
  loop {
    println!("请输入命令：");
    let _ = io::stdout().flush();

    //读取指令，顺手嘲讽
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("赶紧输入啊你个fw");
    let input = input.trim();

    //输入quit就能结束程序了
    if input.eq_ignore_ascii_case("quit") {
      println!("终于能让我下班了你个JetBrain，拜拜您内~");
      break;
    }

    //收集除了quit外的指令
    let parts: Vec<&str> = input.split_whitespace().collect();

    //add <姓名> to <部门> 形式命令
    if parts.len() >=4 && parts[0].eq_ignore_ascii_case("add")&&parts[2].eq_ignore_ascii_case("to") {
      let employee = parts[1].to_string();//给个名儿
      let department_name = parts[3].to_string();//想入的部门

      //加进去咯
      company_departments
        .entry(department_name.clone())
        .or_insert_with(Vec::new)
        .push(employee.clone());
      
      //支会一声怕你不知道哈
      println!("加进去咯老板，您慢慢想慢慢加，太快受不了哈");
      println!("确认一下哈，把{employee}这货加进{department_name}部门是吧，加错了我也管不了哈");
    }

    //List系列指令
    else if parts.len() >= 2 && parts[0].eq_ignore_ascii_case("List") {
      let list_all = parts[1].eq_ignore_ascii_case("all");

      //列出所有员工
      if list_all {
        println!("————Avangers!Assamble!————");
        let mut departments: Vec<(&String, &Vec<String>)> = company_departments.iter().collect();
        departments.sort_by_key(|(department_name, _)| *department_name);

        //公司没人咋办？
        if departments.is_empty() {
          println!("你搞JetBrian呢？毛都没有还叫公司？")
        } else {
          for(department_name, employees) in departments {
            println!("{department_name}部门有哪些人嘞~~~：");

          //部门没人咋办
            if employees.is_empty() {
              println!("这JetBrain的部门有个JetBrain的人啊？");
            } else {
              let mut sorted_employees = employees.clone();
              sorted_employees.sort();
              for employee in sorted_employees {
                println!(" - {employee}");
              }
            }
          println!("————不太华丽的分割线————");
        }
        }
      } else {
        let department_name = parts[1..].join(" ").to_string();
        println!("————{department_name}部门员工列表来啦————");

        if let Some(employees) = company_departments.get(&department_name) {
          if employees.is_empty() {
            println!("想什么呢这都没个员工，做你的青天白日梦去");
          } else {
            let mut sorted_employees = employees.clone();
            sorted_employees.sort();
            for employee in sorted_employees {
              println!(" - {employee}");
            }
          }
        } else {
          println!("🧠糊涂了？根本就没有{department_name}这部门");
        }
      }
    }
    else {
      println!("🦐？给你格式你都输入不对？找个人带你去🏥看看🧠吧？☺️")
    }
    println!("—————华丽的分割线—————");
  }
  //下面是单纯不想一下子退出看不到亲切问候给你个回车的机会 嘿
  println!("按回车退出哟~");
  let mut input = String::new();
  io::stdin().read_line(&mut input).unwrap();
}